@props(['imglink'])

<div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay=".3s">
    <div class="project-item">
        <div class="project-img">
            <img src="{{ asset($imglink) }}" class="img-fluid w-100 rounded" alt="">
            <div class="project-content">
                {{-- <div href="#" class="text-center px-3 py-2 rounded-2" style="background: rgba(9, 9, 32, 0.671);">
                    <h4 class="text-secondary">Exhibition</h4>
                    <p class="m-0 text-white">Advanced Engineering exhibition at Diamond Jubilee</p>
                </div> --}}
            </div>
        </div>
    </div>
</div>
